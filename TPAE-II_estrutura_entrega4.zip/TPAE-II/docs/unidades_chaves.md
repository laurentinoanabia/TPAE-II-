# Unidades, chaves e junções

| Tabela | Unidade de análise | Chave | Periodicidade | Origem |
|---|---|---|---|---|
| T1 escolas_censo | escola × ano do Censo | co_entidade + nu_ano_censo | Anual | F1 |
| T2 escolas_catalogo | escola (cadastro vigente) | co_entidade | Anual (atualizado no ciclo do Censo) | F2 |
| T3 setores_ibge | setor censitário | cd_setor (15 dígitos) | Decenal (2022) | F3 |
| T4 malha_setores | setor censitário (polígono) | cd_setor | Decenal (2022) | F4 |
| T5 resp_gestores | resposta de escola (um registro por resposta) | id_resposta; co_entidade informado pelo respondente | Única, 2026.2 | F8 |
| T6 resp_voluntarios | voluntário (anonimizado) | id_voluntario (código aleatório, sem nome) | Única, 2026.2 | F9 |

## Junções

| Junção | Tabelas | Chave / método | Cardinalidade | Cuidados |
|---|---|---|---|---|
| J1 | T1 com T2 | co_entidade | 1:1 por ano | Usar o mesmo ciclo do Censo nas duas bases; escolas extintas podem faltar no Catálogo |
| J2 | T2 com T4 e T3 | Ponto (lat/long da escola) dentro do polígono do setor, gerando cd_setor; depois cd_setor com T3 | n:1 (várias escolas por setor) | Confirmar se o Catálogo traz coordenadas; sem elas, geocodificar pelo endereço ou agregar por bairro. Setores de 2022 não são comparáveis aos de 2010 |
| J3 | T5 com T1 | co_entidade | 1:1 (escola respondente) | Validar o código informado; descartar respostas sem escola identificável |
| J4 | T6 com T1 | Alocação do voluntário a escola piloto (fase de desenho) | n:1 | Fica agregada (voluntários por escola); nunca identificar o voluntário |
