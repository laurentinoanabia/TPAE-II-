# Plano de aquisição

| Fonte | Método de obtenção | Arquivo / endpoint | Frequência | Parâmetros | Responsável* | Data prevista* | Atualização |
|---|---|---|---|---|---|---|---|
| F1 | Download via script (notebooks/01_aquisicao_censo_escolar.py) | ZIP de microdados do Censo Escolar no portal do INEP | Anual | ano; CO_MUNICIPIO = 2507507; TP_SITUACAO_FUNCIONAMENTO = 1 | Ana | 27/10/2026 | Rodar o script com o novo ano e registrar a data em docs/inventario_fontes.md |
| F2 | Consulta online e exportação manual | Catálogo de Escolas (INEP-Data), filtro João Pessoa | Anual | município; dependência administrativa; etapa | Ana | 27/10/2026 | Reexportar a cada ciclo do Censo |
| F3 | Download manual do portal do IBGE | Censo Demográfico 2022, Agregados por Setores Censitários (arquivo da Paraíba) | Decenal | UF 25; filtrar setores de João Pessoa | Arthur | 03/11/2026 | Sem atualização até novo censo; conferir retificações do IBGE |
| F4 | Download manual do portal do IBGE | Malha de setores censitários 2022 (Paraíba) | Decenal | UF 25; sistema de referência SIRGAS 2000 | Arthur | 03/11/2026 | Idem F3 |
| F5 | Leitura e transcrição dos valores citados | Relatório PISA 2022, Vol. IV | Trienal | Brasil; tabelas IV.B1.2.1 e IV.B2.2.2 | Gabriel | 10/11/2026 | Checar nova edição do PISA |
| F6 | Download manual | Planilhas do Ideb no portal do INEP | Bienal | município e escola; rede pública; anos finais | Gabriel | 10/11/2026 | Atualizar a cada divulgação |
| F7 | Ofício às secretarias (SEMEC-JP e SEE-PB) | Lista de escolas e autorização formal | Única | redes municipal e estadual; ensino médio | Gabriel | Ofício até 27/10/2026 | Reenviar se o prazo estourar; começar por escolas parceiras do CORECON e da UFPB |
| F8 | Formulário online ou aplicação presencial | docs/instrumentos/questionario_gestores | Única | escolas piloto candidatas (T1/T2) | Gabriel e Arthur | Instrumento 10/11; coleta 17/11 a 30/11/2026 | Sem atualização neste projeto |
| F9 | Formulário online | docs/instrumentos/questionario_voluntarios | Única | estudantes de Economia da UFPB | Arthur | Instrumento 10/11; coleta 17/11 a 30/11/2026 | Sem atualização neste projeto |
| F10 | Solicitação ao CORECON-PB | Materiais e termos de parceria | Sob demanda | conteúdos de educação financeira | Ana | 03/11/2026 | Contato direto com o demandante |

* Responsáveis e datas são uma proposta da redação, para a equipe confirmar ou ajustar. Entrega final do projeto: 15/12/2026.
