# Dicionário preliminar

| Variável | Descrição | Tipo | Unidade | Fonte / cobertura |
|---|---|---|---|---|
| nu_ano_censo | Ano de referência do Censo Escolar | inteiro | ano | F1; anual |
| co_entidade | Código INEP da escola (identificador único) | texto (8 dígitos) | código | F1, F2 |
| no_entidade | Nome da escola | texto | – | F1, F2 |
| co_municipio | Código IBGE do município (João Pessoa = 2507507) | texto (7 dígitos) | código | F1, F2; filtro do projeto |
| tp_dependencia | Rede: 1 federal, 2 estadual, 3 municipal, 4 privada | categórica | código | F1 |
| tp_localizacao | Localização: 1 urbana, 2 rural | categórica | código | F1 |
| tp_situacao_funcionamento | Situação: 1 em atividade (manter só as ativas) | categórica | código | F1 |
| no_bairro | Bairro da escola (nome original a confirmar no dicionário do ano; pode vir do Catálogo) | texto | – | F1 ou F2 |
| latitude, longitude | Coordenadas da escola (disponibilidade a confirmar) | numérica | graus decimais | F2 |
| qt_mat_fund_af | Matrículas nos anos finais do fundamental | inteiro | estudantes | F1 |
| qt_mat_med | Matrículas no ensino médio | inteiro | estudantes | F1 |
| qt_mat_bas | Matrículas totais na educação básica | inteiro | estudantes | F1; denominador de porte |
| cd_setor | Código do setor censitário | texto (15 dígitos) | código | F3, F4 |
| pop_total_setor | Pessoas residentes no setor (nome original a confirmar no dicionário do IBGE) | inteiro | pessoas | F3; Censo 2022 |
| dom_total_setor | Domicílios no setor (nome original a confirmar) | inteiro | domicílios | F3; Censo 2022 |
| id_resposta | Identificador da resposta ao questionário de gestores/professores | texto | código | F8; sem dado pessoal |
| tem_atividade_ef | A escola realiza atividade de educação financeira (0 não, 1 sim) | binária | 0/1 | F8; escolas respondentes |
| freq_atividade_ef | Frequência: nunca, eventual, semestral, mensal, semanal | categórica | categoria | F8 |
| tema_prioritario | Temas priorizados (orçamento, consumo, endividamento, poupança, crédito, investimento, outro); uma linha por tema | categórica | categoria | F8 |
| id_voluntario | Código aleatório do voluntário (sem nome nem matrícula) | texto | código | F9 |
| semestre_curso | Semestre cursado em Economia (para a comparação por faixa) | inteiro | semestre | F9 |
| horas_semanais | Horas semanais que o voluntário pode dedicar | numérica | horas/semana | F9 |
| interesse_voluntario | Nível de interesse: baixo, médio, alto | categórica | categoria | F9 |
| pisa_pct_baixo_desempenho | Estudantes brasileiros abaixo do nível 2 em letramento financeiro (45,1%) | numérica | % | F5; Brasil, 2022; só referência |
