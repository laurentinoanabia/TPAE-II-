# Tarefas

| # | Tarefa | Responsável* | Prazo* | Situação |
|---|---|---|---|---|
| 1 | Reorganizar o repositório na estrutura da Entrega 4, subir a E03 em docs/ e remover o 'README (2).md' duplicado | Ana | 20/10/2026 | Em andamento |
| 2 | Conferir o acesso do professor ao repositório e testar todos os links | Ana | 20/10/2026 | A fazer |
| 3 | Baixar o Censo Escolar mais recente, filtrar João Pessoa e reconciliar com os números da Entrega 3 (495 escolas; 19.532 de 29.169 no médio) | Ana | 27/10/2026 | A fazer |
| 4 | Exportar o Catálogo de Escolas (endereço, bairro e coordenadas, se houver) | Ana | 27/10/2026 | A fazer |
| 5 | Enviar ofícios à SEMEC-JP e à SEE-PB pedindo lista de escolas e autorização | Gabriel | 27/10/2026 | A fazer |
| 6 | Baixar agregados por setor e malha 2022; testar a junção espacial J2 | Arthur | 03/11/2026 | A fazer |
| 7 | Solicitar materiais e confirmar o apoio do CORECON-PB | Ana | 03/11/2026 | A fazer |
| 8 | Elaborar os questionários (gestores/professores e voluntários) e os termos de autorização | Gabriel e Arthur | 10/11/2026 | A fazer |
| 9 | Aplicar os questionários e anonimizar as respostas | Gabriel e Arthur | 30/11/2026 | A fazer |
| 10 | Registrar data de acesso e licença de cada fonte no inventário a cada download | Todos | Contínuo | A fazer |

* Proposta da redação; ajustar conforme a divisão real do grupo. Podem virar Issues no GitHub.
