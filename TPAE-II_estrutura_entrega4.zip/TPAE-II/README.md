# Educação financeira nas escolas de João Pessoa: diagnóstico para um piloto voluntário

Projeto aplicado de extensão da disciplina **PSAE00320 – Técnicas de Pesquisa e Análise Econômica II (TPAE II)**, Turma 01, 2026.2, Curso de Ciências Econômicas da UFPB.

## Equipe

- Ana Beatriz Laurentino
- Arthur Almeida
- Gabriel Pinheiro

**Orientador:** Prof. Alessio

## Demandante

**CORECON-PB** (Conselho Regional de Economia da Paraíba), em parceria com estudantes de Ciências Econômicas da UFPB.

## Problema

Estudantes do ensino médio chegam à vida adulta sem educação financeira, que não faz parte do currículo obrigatório das escolas. A ideia é criar uma iniciativa voluntária em que estudantes de Economia da UFPB, em parceria com o CORECON-PB, ensinem educação financeira em escolas de João Pessoa. Hoje não há diagnóstico de quais escolas, quais conteúdos e que capacidade de voluntários existem para desenhar esse programa.

## Pergunta

Que perfil de escolas, conteúdos e capacidade de voluntários deve orientar uma iniciativa de educação financeira conduzida por estudantes de Economia da UFPB, em parceria com o CORECON-PB, em escolas de João Pessoa?

## Fontes

Inventário completo (instituição, link, cobertura, formato, acesso, licença e data de acesso) em [`docs/inventario_fontes.md`](docs/inventario_fontes.md). Resumo:

| ID | Fonte | Uso |
|---|---|---|
| F1 | Censo Escolar (INEP) | Escolas, rede, etapa e matrículas |
| F2 | Catálogo de Escolas (INEP) | Endereço, contato e oferta |
| F3 e F4 | Censo 2022 (IBGE): agregados e malha de setores | Perfil socioeconômico do entorno |
| F5 e F6 | PISA 2022 (OCDE) e Ideb (INEP) | Contexto de letramento e aprendizagem |
| F7 | Secretarias de educação (municipal e estadual) | Contatos e autorização |
| F8 e F9 | Questionários próprios (gestores/professores e voluntários) | Oferta, temas e capacidade voluntária |
| F10 e F11 | CORECON-PB; BNCC e ENEF | Apoio institucional e referência |

Unidades, chaves e junções: [`docs/unidades_chaves.md`](docs/unidades_chaves.md). Dicionário: [`docs/dicionario_preliminar.md`](docs/dicionario_preliminar.md). Aquisição: [`docs/plano_aquisicao.md`](docs/plano_aquisicao.md). Tarefas: [`docs/tarefas.md`](docs/tarefas.md).

## Estrutura de pastas

```
.
├── README.md
├── .gitignore
├── data/
│   ├── raw/          # dados originais permitidos (grandes ficam fora do Git)
│   └── processed/    # dados tratados e anonimizados
├── notebooks/        # aquisição, tratamento e análise
├── docs/             # planos, inventário, dicionário e instrumentos
└── outputs/          # tabelas, gráficos e produtos
```

## Como reproduzir

1. Leia `docs/plano_aquisicao.md` e baixe os arquivos indicados (os brutos não são versionados).
2. Registre a data de acesso de cada fonte em `docs/inventario_fontes.md`.
3. Rode `python notebooks/01_aquisicao_censo_escolar.py CAMINHO_DO_ZIP ANO` para gerar `data/processed/escolas_jp_ANO.csv`. Requer `pandas`.

## Segurança

Nunca versionar senhas, tokens, chaves, dados pessoais, documentos internos ou bases restritas. Respostas de questionários só entram anonimizadas.

## Situação atual

- **Entrega 3 (01/10/2026):** definição do problema e plano de pesquisa. Plano em `docs/E03_equipe01_plano.pdf`.
- **Entrega 4 (20/10/2026):** repositório e plano de dados.
- Próximos passos: baixar o Censo Escolar, enviar ofícios às secretarias, elaborar os questionários.
- **Entrega final:** 15/12/2026.

## Contato acadêmico

Prof. Alessio · Curso de Ciências Econômicas, UFPB. Contato central da equipe: Ana Beatriz (laurentino.anabia@gmail.com).
